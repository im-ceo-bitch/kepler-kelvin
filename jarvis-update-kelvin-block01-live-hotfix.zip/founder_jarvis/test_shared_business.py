import asyncio, datetime as dt, json, unittest
from founder_jarvis import shared_business as b
class MockResponse:
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,*args):return b'{"ok":true}'
class Opener:
    def __init__(self):self.requests=[]
    def open(self,req,timeout):self.requests.append(req);return MockResponse()
class BridgeTests(unittest.TestCase):
    def test_token_validation_and_fixed_https_origin(self):
        with self.assertRaises(ValueError):b.Bridge('bad')
        op=Opener();bridge=b.Bridge('a'*64,op);bridge.enqueue('id-123456','привет',True)
        req=op.requests[0];self.assertEqual(req.full_url,b.ORIGIN+'/api/internal/kelvin/message');self.assertEqual(req.get_header('Authorization'),'Bearer '+'a'*64);self.assertEqual(json.loads(req.data)['voice'],True)
        with self.assertRaises(ValueError):bridge.call('https://wrong')
    def test_descriptive_user_agent_on_all_bridge_actions(self):
        op=Opener();bridge=b.Bridge('a'*64,op)
        for action in ('message','claim','finish','heartbeat','remember','memory','forget','records','autonomy','care','diagnostics'):
            bridge.call(action)
        self.assertEqual(len(op.requests),11)
        for req in op.requests:
            self.assertEqual(req.get_header('User-agent'),'Kelvin/7 (+https://iumrah.app)')
            self.assertEqual(req.get_header('Authorization'),'Bearer '+'a'*64)
    def test_daily_deterministic_and_no_before_eight(self):
        op=Opener();bridge=b.Bridge('a'*64,op);bridge.daily(dt.datetime(2026,11,27,7));self.assertFalse(op.requests)
        bridge.daily(dt.datetime(2026,11,27,8));bridge.daily(dt.datetime(2026,11,27,19));self.assertEqual(json.loads(op.requests[0].data),json.loads(op.requests[1].data))
    def test_context_contains_both_channels_and_notes(self):
        p={'job':{'prompt':'продолжи'},'history':[{'prompt':'из приложения','answer':'ok','source':'app','status':'done'},{'prompt':'из Telegram','answer':'ok','source':'telegram','status':'done'}],'snapshot':{'asOf':'today'},'memory':[{'content':'note'}]}
        prompt,history=b.answer_context(p,['local']);self.assertIn('today',prompt);self.assertIn('продолжи',prompt);self.assertEqual(history[1]['user'],'из приложения');self.assertEqual(history[2]['user'],'из Telegram');self.assertEqual(history[0]['shared_owner_notes'],['note'])
class LoopTests(unittest.IsolatedAsyncioTestCase):
    async def test_persist_before_notify(self):
        calls=[]; stop=asyncio.Event()
        class Fake:
            def daily(self,*a):pass
            def call(self,action,data=None):
                calls.append(action)
                if action=='claim':return {'job':{'id':'test-id','source':'telegram','voice':True,'lease':'test','prompt':'Привет'},'history':[],'memory':[],'typedMemory':[],'snapshot':{}}
                if action=='finish':self.data=data
                return {'ok':True}
        fake=Fake()
        async def notify(answer,voice):
            self.assertEqual(fake.data['answer'],'Ответ');self.assertTrue(voice);self.assertIn('finish',calls);stop.set()
        await asyncio.wait_for(b.loop(fake,stop,lambda p,h:'Ответ',notify,lambda:[],asyncio.Lock()),3)
        self.assertEqual(fake.data['status'],'done')

class QueueDiagnosticsTests(unittest.IsolatedAsyncioTestCase):
    async def test_empty_answer_saved_as_failure(self):
        stop=asyncio.Event()
        class Fake:
            def call(self,action,data=None):
                if action=='claim':return {'job':{'id':'test-id','source':'telegram','voice':False,'lease':'test','prompt':'Привет'},'history':[],'typedMemory':[],'snapshot':{}}
                if action=='finish':self.result=data
                return {'ok':True}
        fake=Fake()
        async def notify(answer,voice):stop.set()
        with self.assertLogs('kelvin.shared',level='WARNING') as logs:
            await asyncio.wait_for(b.loop(fake,stop,lambda p,h:'  ',notify,lambda:[],asyncio.Lock()),3)
        self.assertEqual(fake.result['status'],'failed')
        self.assertTrue(fake.result['answer'].strip())
        self.assertTrue(any('Queue job failed at model' in line for line in logs.output))
    async def test_claim_error_logged_without_secret(self):
        stop=asyncio.Event()
        class Fake:
            def call(self,action,data=None):
                if action=='claim':raise RuntimeError('HTTP 503 UNAVAILABLE secret-that-must-not-be-logged')
                return {'ok':True}
        async def notify(*args):pass
        with self.assertLogs('kelvin.shared',level='WARNING') as logs:
            with self.assertRaises(asyncio.TimeoutError):
                await asyncio.wait_for(b.loop(Fake(),stop,lambda p,h:'ok',notify,lambda:[],asyncio.Lock()),.1)
        output=' '.join(logs.output)
        self.assertIn('Queue loop failed at claim: 503 UNAVAILABLE',output)
        self.assertNotIn('secret-that-must-not-be-logged',output)

    async def test_foundation_receipt_only_after_delivery(self):
        import hashlib
        stop=asyncio.Event(); ident='foundation-probe-'+'a'*24+'-1'
        class Fake:
            def call(self,action,data=None):
                if action=='claim': return {'job':{'id':ident,'source':'telegram','voice':False,'lease':'test','prompt':'Привет'},'history':[],'memory':[],'typedMemory':[],'snapshot':{}}
                if action=='finish':self.finished=True
                return {'ok':True}
        fake=Fake()
        async def notify(answer,voice):
            self.assertTrue(fake.finished);stop.set()
        with self.assertLogs('kelvin.shared',level='WARNING') as logs:
            await asyncio.wait_for(b.loop(fake,stop,lambda p,h:'Сапфир.\n\n[Локальный резерв: Claude временно недоступен; ответ требует проверки.]',notify,lambda:[],asyncio.Lock()),3)
        digest=hashlib.sha256('сапфир'.encode()).hexdigest()
        from founder_jarvis.operations import redact_log
        receipt='Foundation receipt '+ident+' done '+digest[:32]+':'+digest[32:]
        self.assertIn(receipt,redact_log(' '.join(logs.output)))
        self.assertNotIn('Сапфир',' '.join(logs.output))
